﻿using ConsoleApp2.Behavioral;
using ConsoleApp2.SOLID;
using ConsoleApp2.Structral;
using ConsoleApp2.Structral.Factory;

Console.WriteLine("Hello, World!");

#region SOLID
//Square square = new Square(5.5);
//Circle circle = new(1.5);
//Shape[] shapes = {square, circle};
//foreach (Shape shape in shapes)
//{
//    Console.WriteLine(shape.GetArea());
//}
//HospitalDb hospitalDb = new HospitalDb();
//Department department = new(hospitalDb);
#endregion

#region Pattern Designs
#region Structral
//for (int i = 0; i < 10; i++)
//{
//    Singleton.GetInstance();
//}
//Singleton s2 = Singleton.GetInstance();
//Singleton s3 = Singleton.GetInstance();

//IPhone s23 = Factory.GetPhone("s23", 256);
//IPhone note10 = Factory.GetPhone("note10", 1024);
//Console.WriteLine(s23);
//Console.WriteLine(note10);

//NewSystem newSystem = new();
//OldSystemAdaptor oldSystemAdaptor = new();
//Command command = new Command();
//command.Run(oldSystemAdaptor);
int[] numbers = { 100, 29, 2000, 543, 789 };
CreateIterator.GetIterator(numbers);

#endregion
#endregion
