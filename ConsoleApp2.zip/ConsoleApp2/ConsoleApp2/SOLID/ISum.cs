﻿namespace ConsoleApp2.SOLID;

internal interface ISum
{
    double Sum(double n1, double n2);
}
