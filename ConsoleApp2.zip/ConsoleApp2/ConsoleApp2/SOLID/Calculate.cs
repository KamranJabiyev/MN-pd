﻿namespace ConsoleApp2.SOLID;

internal class Calculate : ISum,IDivide,IDifference,IMultaple
{
    public double Difference(double n1, double n2)
    {
        throw new NotImplementedException();
    }

    public double Divide(double n1, double n2)
    {
        throw new NotImplementedException();
    }

    public double Multiple(double n1, double n2)
    {
        throw new NotImplementedException();
    }

    public double Sum(double n1, double n2)
    {
        throw new NotImplementedException();
    }
}
