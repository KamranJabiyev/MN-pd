﻿namespace ConsoleApp2.SOLID;

internal interface IMultaple
{
    double Multiple(double n1, double n2);
}
