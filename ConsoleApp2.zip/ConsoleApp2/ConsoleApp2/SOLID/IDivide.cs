﻿namespace ConsoleApp2.SOLID;

internal interface IDivide
{
    double Divide(double n1, double n2);
}
