﻿namespace ConsoleApp2.SOLID;

public abstract class Shape
{
    public abstract double GetArea();
    //public double GetArea(string shape,double width=0,double radius=0)
    //{
    //    switch (shape)
    //    {
    //        case "circle":
    //            return 3.14 * Math.Pow(radius, 2);
    //            break;
    //        case "square":
    //            return Math.Pow(width, 2);
    //            break;
    //        default: return 0;
    //    }
    //}
}
