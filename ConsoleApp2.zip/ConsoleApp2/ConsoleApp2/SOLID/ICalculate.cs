﻿namespace ConsoleApp2.SOLID;

public interface ICalculate
{
    double Sum(double n1, double n2);
    double Difference(double n1, double n2);
    double Divide(double n1, double n2);
    double Multiple(double n1, double n2);
}
