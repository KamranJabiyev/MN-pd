﻿namespace ConsoleApp2.SOLID;

internal class HospitalDb: IDbContext
{
}
