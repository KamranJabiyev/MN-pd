﻿namespace ConsoleApp2.SOLID;

internal class Department
{
    public IDbContext context { get; set; }
    public Department(IDbContext dbContext)
    {
        context = dbContext;
    }
}
