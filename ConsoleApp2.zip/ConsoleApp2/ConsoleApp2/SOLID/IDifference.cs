﻿namespace ConsoleApp2.SOLID;

internal interface IDifference
{
    double Difference(double n1, double n2);
}
