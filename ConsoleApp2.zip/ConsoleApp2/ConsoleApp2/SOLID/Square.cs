﻿namespace ConsoleApp2.SOLID;

public class Square:Shape
{
    public double Length { get; set; }
    public Square(double length)
    {
        Length = length;
    }


    public override double GetArea()
    {
        return CalculateArea();
    }

    private double CalculateArea() => Math.Pow(Length, 2);
}
