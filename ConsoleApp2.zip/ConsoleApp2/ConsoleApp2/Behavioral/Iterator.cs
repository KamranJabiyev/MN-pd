﻿namespace ConsoleApp2.Behavioral;

public class Iterator
{
    private int[] items;
    private int index=0;
    public Iterator(int[] items)
    {
        this.items = items;
    }

    public bool HasNext()
    {
        return index < items.Length;
    }
    public int Next()
    {
        if(HasNext())
        {
            return items[index++];
        }
        else
        {
            throw new Exception("Out of range");
        }
    }
}
