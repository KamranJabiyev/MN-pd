﻿namespace ConsoleApp2.Behavioral;

public class CreateIterator
{
    public static void GetIterator(int[] items)
    {
        Iterator iterator = new(items);
        while(iterator.HasNext())
        {
            Console.WriteLine(iterator.Next());
        }
    }
}
