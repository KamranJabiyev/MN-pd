﻿namespace ConsoleApp2.Structral;

public class Singleton
{
    private static Singleton obj;
    private Singleton()
    {
        Console.WriteLine("Object created");
    }

    public static Singleton GetInstance()
    {
        
        obj ??= new Singleton();
        return obj;
    }
}
