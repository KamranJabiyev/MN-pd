﻿namespace ConsoleApp2.Structral.AbstractFactory;

internal class Note10:IPhone
{
    public Note10(string name, int memory)
    {
        Name = name;
        Memory = memory;
    }

    public string Name { get; set; }
    public int Memory { get; set; }

    public override string ToString()
    {
        return $"{Name} {Memory}";
    }
}
