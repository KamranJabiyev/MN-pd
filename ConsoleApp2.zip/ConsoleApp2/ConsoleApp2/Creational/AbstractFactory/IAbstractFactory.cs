﻿namespace ConsoleApp2.Structral.AbstractFactory;

public interface IAbstractFactory
{
    IPhone GetPhone(string name,int memory);
}
