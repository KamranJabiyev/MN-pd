﻿namespace ConsoleApp2.Structral.AbstractFactory;

public class Note10Factory : IAbstractFactory
{
    public IPhone GetPhone(string name, int memory)
    {
        return new Note10(name, memory);
    }
}
