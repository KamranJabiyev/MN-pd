﻿namespace ConsoleApp2.Structral.AbstractFactory;

public interface IPhone
{
    string Name { get; set; }
    int Memory { get; set; }
}
