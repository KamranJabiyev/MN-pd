﻿namespace ConsoleApp2.Structral.AbstractFactory;

public class S23Factory : IAbstractFactory
{
    public IPhone GetPhone(string name, int memory)
    {
        return new S23(name, memory);
    }
}
