﻿namespace ConsoleApp2.Structral.Factory;

public interface IPhone
{
    string Name { get; set; }
    int Memory { get; set; }
}
