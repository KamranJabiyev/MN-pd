﻿namespace ConsoleApp2.Structral.Factory;

public class Factory
{
    public static IPhone GetPhone(string name,int memory)
    {
        if (String.Equals(name, "S23", StringComparison.OrdinalIgnoreCase))
        {
            return new S23(name, memory);
        }
        else if(String.Equals(name, "Note10", StringComparison.OrdinalIgnoreCase))
        {
            return new Note10(name, memory);
        }
        else
        {
            throw new Exception("Enter correct format");
        }
    }
}
