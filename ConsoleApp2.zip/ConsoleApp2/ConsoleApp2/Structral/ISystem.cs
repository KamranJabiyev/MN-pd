﻿

namespace ConsoleApp2.Structral;

public interface ISystem
{
    void DoSomething();
}
