﻿namespace ConsoleApp2.Structral;

public class OldSystem
{
    public void DoSometing()
    {
        Console.WriteLine("Old version");
    }
}
