﻿namespace ConsoleApp2.Structral;

public class NewSystem:ISystem
{
    public void DoSomething()
    {
        Console.WriteLine("New version");
    }
}
