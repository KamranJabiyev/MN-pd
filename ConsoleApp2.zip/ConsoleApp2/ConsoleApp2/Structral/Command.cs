﻿namespace ConsoleApp2.Structral;

public class Command
{
    public void Run(ISystem sytem)
    {
        sytem.DoSomething();
    }
}
