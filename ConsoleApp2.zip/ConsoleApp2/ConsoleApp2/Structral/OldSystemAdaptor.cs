﻿namespace ConsoleApp2.Structral;

internal class OldSystemAdaptor : ISystem
{
    public void DoSomething()
    {
        OldSystem oldSystem = new();
        oldSystem.DoSometing();
    }
}
